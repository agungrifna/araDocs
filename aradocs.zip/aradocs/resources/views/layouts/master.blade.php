<!doctype html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Agripa | Author</title>
        <!-- Css -->
        <link rel="stylesheet" href="/assets/styles/style.css">

        <!-- Bootstraps -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
            crossorigin="anonymous">

        <!-- Googgle Icons -->
        <link rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0"
            />
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>

        @include('partials.navbar1')
        @include('partials.navbar2')


        <!-- Jumbotron -->
        <section class="">
            <div class="container">
                <div class="row py-3 py-lg-4">
                    <div class="col-lg-6">
                        <div class="mx-1 mx-lg-3">
                            <a href=""><img
                                    src="/assets/images/avatars/avatar-2.jpg"
                                    class="img-fluid d-block mx-auto py-4"
                                    alt="" width="440"></a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text-center text-lg-start mx-1
                            mx-lg-3">
                            <h5 class="py-2">Persembahan bagi yang membutuhkan
                            </h5>
                            <h1 class="py-2">Hay, salam kenal <br>saya <a
                                    href="">Agung Rifna Ajie</a>
                            </h1>
                            <h5 class="py-2"><a href="">Teacher</a> | <a
                                    href="">Web Developer</a> | <a href="">Amateur
                                    Movie Maker</a>
                            </h5>
                            <p class="lead py-2">Lorem ipsum dolor sit amet
                                consectetur adipisicing elit. Est eligendi
                                excepturi, quia culpa esse voluptates dipisicing
                                elit est eligendi
                            </p>
                            <a class="btn btn-secondary text-light" href="#"
                                role="button">Hubungi Saya</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Jumbotron -->

        <!-- Card -->
        <section class="">
            <div class="container py-4">
                <div class="text-center">
                    <h2>Dokumentasi</h2>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 my-3">
                        <div class="mx-1 card">
                            <div class="text-center p-3">
                                <li class="list-inline-item my-lg-1"><a
                                        href="/"><img
                                            src="/assets/images/logos/logo2.jpg"
                                            alt="" width="200"></a></li>
                                <p class="my-lg-1 mx-2">Lorem ipsum dolor sit,
                                    amet
                                    consectetur adipisicing elit. Repellendus
                                    tempore at ipsum.
                                    Asperiores expedita consequatur aspernatur
                                    doloribus est ad tempore.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 my-3">
                        <div class="mx-1 card">
                            <div class="text-center p-3">
                                <li class="list-inline-item my-lg-1"><a
                                        href="/"><img
                                            src="/assets/images/logos/logo2.jpg"
                                            alt="" width="200"></a></li>
                                <p class="my-lg-1 mx-2">Lorem ipsum dolor sit,
                                    amet
                                    consectetur adipisicing elit. Repellendus
                                    tempore at ipsum.
                                    Asperiores expedita consequatur aspernatur
                                    doloribus est ad tempore.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 my-3">
                        <div class="mx-1 card">
                            <div class="text-center p-3">
                                <li class="list-inline-item my-lg-1"><a
                                        href="/"><img
                                            src="/assets/images/logos/logo2.jpg"
                                            alt="" width="200"></a></li>
                                <p class="my-lg-1 mx-2">Lorem ipsum dolor sit,
                                    amet
                                    consectetur adipisicing elit. Repellendus
                                    tempore at ipsum.
                                    Asperiores expedita consequatur aspernatur
                                    doloribus est ad tempore.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 my-3">
                        <div class="mx-1 card">
                            <div class="text-center p-3">
                                <li class="list-inline-item my-lg-1"><a
                                        href="/"><img
                                            src="/assets/images/logos/logo2.jpg"
                                            alt="" width="200"></a></li>
                                <p class="my-lg-1 mx-2">Lorem ipsum dolor sit,
                                    amet
                                    consectetur adipisicing elit. Repellendus
                                    tempore at ipsum.
                                    Asperiores expedita consequatur aspernatur
                                    doloribus est ad tempore.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Card -->

        <!-- Footer -->
        @include('partials.footer')
        <!-- End Footer -->


        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
            crossorigin="anonymous"></script>
    </body>

</html>
