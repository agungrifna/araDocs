<header class="sticky-top">
    <nav id="navbar_top" class="navbar navbar-expand-lg navbar-dark
        bg-dark py-3">
        <div class="container">
            <nav class="navbar">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item mx-lg-1 ps-2"><a href="/"><img
                                src="https://www.upi.edu/images/kampus-merdeka.png"
                                alt="" width="60"></a></li>
                </ul>
            </nav>
            <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse" data-bs-target="#navbar1"
                aria-controls="navbar1" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="material-symbols-outlined">menu</span>
            </button>
            <div class="collapse navbar-collapse" id="navbar1">
                <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                    <li class="nav-item mx-lg-2">
                        <a class="nav-link active" href="/">Beranda</a>
                    </li>
                    <li class="nav-item mx-lg-2">
                        <a class="nav-link active" href="/">Dokumentasi</a>
                    </li>
                    <li class="nav-item mx-lg-2">
                        <a class="nav-link active" href="/">Portofolio</a>
                    </li>
                    <li class="nav-item mx-lg-2">
                        <a class="nav-link active" href="/">Artikel</a>
                    </li>
                    <li class="nav-item mx-lg-2">
                        <a class="nav-link active" href="/">Agenda</a>
                    </li>
                    <li class="nav-item mx-lg-2">
                        <a class="nav-link active" href="/">Tentang
                            Saya</a>
                    </li>
                    <li class="nav-item mx-lg-2">
                        <a class="nav-link active" href="/">Kontak</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\aradocs\resources\views/partials/navbar2.blade.php ENDPATH**/ ?>