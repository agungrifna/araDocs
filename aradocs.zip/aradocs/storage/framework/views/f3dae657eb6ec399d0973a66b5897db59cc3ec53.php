<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary py-1">
        <div class="container">
            <ul class="list-inline mb-0">
                <li class="list-inline-item mx-lg-1"><a href="/"><img
                            src="/assets/images/flags/uk.png" alt=""
                            width=""></a></li>
                <li class="list-inline-item mx-lg-1"><a href="/"><img
                            src="/assets/images/flags/id.png" alt=""
                            width=""></a></li>
            </ul>
            <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse" data-bs-target="#navbar2"
                aria-controls="navbar2" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="material-symbols-outlined">more_vert</span>
            </button>
            <div class="collapse navbar-collapse" id="navbar2">
                <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                    <li class="nav-item secondary mx-lg-2">
                        <a class="nav-link active" href="/">Author</a>
                    </li>
                    <li class="nav-item secondary mx-lg-2">
                        <a class="nav-link active" href="/">P. Sosiologi</a>
                    </li>
                    <li class="nav-item secondary mx-lg-2">
                        <a class="nav-link active" href="/">P. IPS</a>
                    </li>
                    <li class="nav-item secondary mx-lg-2">
                        <a class="nav-link active" href="/">Sitem
                            Informasi</a>
                    </li>
                    <li class="nav-item secondary mx-lg-2">
                        <a class="nav-link active" href="/">Arsip</a>
                    </li>
                    <li class="nav-item secondary mx-lg-2">
                        <a class="nav-link active" href="/">MovieOn</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\aradocs\resources\views/partials/navbar1.blade.php ENDPATH**/ ?>