<footer class="bg-dark">
    <div class="container text-light">
        <div class="row pt-4 pb-2">
            <div class="col-md-4 text-md-start text-center">
                <ul class="list-inline mb-md-0 ps-md-2">
                    <li class="list-inline-item"><a href="/"><img
                    src="https://www.upi.edu/images/kampus-merdeka.png"
                    alt="" width="60"></a></li>
                </ul>
            </div>
            <div class="col-md-4 text-center">
                <ul class="list-inline">
                    <li class="list-inline-item mx-lg-1"><a class="fa
                    fa-youtube" href="/"></a></li>
                    <li class="list-inline-item mx-lg-1"><a class="fa
                    fa-instagram" href="/"></a></li>
                    <li class="list-inline-item mx-lg-1"><a class="fa
                    fa-twitter" href="/"></a></li>
                    <li class="list-inline-item mx-lg-1"><a class="fa
                    fa-github" href="/"></a></li>
                    <li class="list-inline-item mx-lg-1"><a class="fa
                    fa-linkedin" href="/"></a></li>
                </ul>
            </div>
            <div class="col-md-4 text-md-end text-center">
                <ul class="list-inline">
                    <li class="list-inline-item">&copy; 2022 <a href="/">kitakumpul.online</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\aradocs\resources\views/partials/footer.blade.php ENDPATH**/ ?>